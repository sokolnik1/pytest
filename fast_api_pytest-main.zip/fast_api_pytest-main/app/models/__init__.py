# for Alembic and unit tests
from app.models.user import *