## Как запустить тесты
1. Создайте тестовую базу данных
2. Создайте локальный интерпретатор venv. 
3. pip install poetry
4. poetry install
5. pytest
